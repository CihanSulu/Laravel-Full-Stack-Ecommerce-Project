<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class siparisUrun extends Model
{
    protected $table = "tbl_siparis_urun";
    public $timestamps = false;
}
