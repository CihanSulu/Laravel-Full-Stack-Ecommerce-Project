<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mailler extends Model
{
    protected $table = "tbl_mail";
    public $timestamps = false;
}
